// EKOfarm – herní pravidla. Sdílí je server (Worker) i prohlížeč.
// Čisté funkce bez DOM a bez přístupu k síti. Čas se vždy předává zvenku (ms).

export const RULES_VERSION = 9;
export const GRID_W = 17;
export const GRID_H = 17;
export const MAIN_POS = [7, 7];   // Statek 3×3 přesně uprostřed mřížky 17×17

// ---------- pozemky ----------
// základ farmy je 0..16 × 0..16; kolem něj se dá dokoupit 8 pozemků (svět −8..24)
export const WORLD = { x0: -8, y0: -8, x1: 25, y1: 25 };
export const LAND_PARCELS = [
  { id: 'n',  name: 'Louka u lesa',     x: 0,   y: -8, w: 17, h: 8 },
  { id: 'e',  name: 'Pole u cesty',     x: 17,  y: 0,  w: 8,  h: 17 },
  { id: 's',  name: 'Údolí u potoka',   x: 0,   y: 17, w: 17, h: 8 },
  { id: 'w',  name: 'Slunná stráň',     x: -8,  y: 0,  w: 8,  h: 17 },
  { id: 'ne', name: 'Horní pastviny',   x: 17,  y: -8, w: 8,  h: 8, needs: ['n', 'e'] },
  { id: 'se', name: 'Dolní pastviny',   x: 17,  y: 17, w: 8,  h: 8, needs: ['s', 'e'] },
  { id: 'sw', name: 'Rybníková louka',  x: -8,  y: 17, w: 8,  h: 8, needs: ['s', 'w'] },
  { id: 'nw', name: 'Lesní mýtina',     x: -8,  y: -8, w: 8,  h: 8, needs: ['n', 'w'] },
];
// cena a potřebná úroveň podle toho, kolikátý pozemek kupuješ
export const LAND_PRICES = [1500, 3000, 5000, 8000, 12000, 16000, 20000, 25000];
export const LAND_LEVELS = [5, 6, 7, 8, 9, 10, 11, 12];
export const getParcel = id => LAND_PARCELS.find(p => p.id === id) || null;
export function parcelAt(x, y) {
  return LAND_PARCELS.find(p => x >= p.x && x < p.x + p.w && y >= p.y && y < p.y + p.h) || null;
}
export function landOwned(farm, x, y) {
  if (x >= 0 && y >= 0 && x < GRID_W && y < GRID_H) return true;
  const p = parcelAt(x, y);
  return !!p && farm.land.includes(p.id);
}
// lze pozemek koupit (sousedí s farmou)? rohový potřebuje aspoň jeden sousední boční
export const landReachable = (farm, p) => !p.needs || p.needs.some(id => farm.land.includes(id));
export const landPrice = farm => LAND_PRICES[Math.min(farm.land.length, LAND_PRICES.length - 1)];
export const landLevel = farm => LAND_LEVELS[Math.min(farm.land.length, LAND_LEVELS.length - 1)];
export const START_COINS = 50;
export const SILO_START = 50;
export const SILO_STEP = 25;
export const QUEUE_SIZE = 3;
export const FREE_PLOTS = 6;        // prvních 6 polí je zdarma
export const PLOTS_PER_LEVEL = 6;   // s každou úrovní 6 dalších polí
export const ORDER_SLOTS = 6;
export const FIELD_CELL_PRICE = 8;  // cena jednoho políčka velkého pole
export const FIELD_MIN = 3;
export const FIELD_MAX = 6;
export const ORDER_WAIT = 3 * 60;   // s – nová zakázka po zrušení
export const START_PLOTS = [
  [11, 8], [12, 8], [13, 8],
  [11, 9], [12, 9], [13, 9],
];

// ---------- data ----------
// time = sekundy; look = jak se rostlina kreslí (t = tvar, c = barva plodu)
// harvester = čím se plodina sklízí na velkém poli (combine = kombajn, tractor = traktor se sklízečem)
const crop = (id, name, cat, level, cost, time, price, xp, harvester, look) =>
  ({ id, name, cat, level, cost, time, yield: 2, xp, price, icon: id, harvester, look });
export const CROPS = {
  // obilí a technické plodiny
  wheat:     crop('wheat',     'Pšenice',      'obili',    1, 1,  60,   3,  1, 'combine', { t: 'grain' }),
  corn:      crop('corn',      'Kukuřice',     'obili',    2, 3,  300,  8,  2, 'combine', { t: 'tall' }),
  soy:       crop('soy',       'Sója',         'obili',    5, 8,  1200, 18, 4, 'combine', { t: 'soy' }),
  repka:     crop('repka',     'Řepka',        'obili',    6, 10, 1500, 22, 5, 'combine', { t: 'repka' }),
  sun:       crop('sun',       'Slunečnice',   'obili',    7, 12, 1800, 26, 5, 'combine', { t: 'sun' }),
  hrach:     crop('hrach',     'Hrách',        'zelenina', 9, 9,  1500, 21, 5, 'combine', { t: 'pod', c: '#7cc04f' }),
  // zelenina
  redkvicka: crop('redkvicka', 'Ředkvička',    'zelenina', 1, 2,  120,  4,  1, 'tractor', { t: 'root', c: '#e0405a' }),
  salat:     crop('salat',     'Salát',        'zelenina', 2, 2,  180,  5,  1, 'tractor', { t: 'leafy', c: '#8fd45a' }),
  carrot:    crop('carrot',    'Mrkev',        'zelenina', 3, 5,  600,  12, 3, 'tractor', { t: 'carrot' }),
  rajce:     crop('rajce',     'Rajče',        'zelenina', 3, 4,  480,  9,  2, 'tractor', { t: 'bush', c: '#e0402d' }),
  potato:    crop('potato',    'Brambory',     'zelenina', 4, 6,  900,  15, 3, 'tractor', { t: 'potato' }),
  okurka:    crop('okurka',    'Okurka',       'zelenina', 4, 4,  540,  10, 2, 'tractor', { t: 'vine', c: '#3f8f3a' }),
  cibule:    crop('cibule',    'Cibule',       'zelenina', 5, 5,  720,  11, 3, 'tractor', { t: 'bulb', c: '#d9a441' }),
  cesnek:    crop('cesnek',    'Česnek',       'zelenina', 6, 6,  900,  14, 3, 'tractor', { t: 'bulb', c: '#f2ede0' }),
  paprika:   crop('paprika',   'Paprika',      'zelenina', 7, 7,  1080, 16, 4, 'tractor', { t: 'bush', c: '#e8502a' }),
  beet:      crop('beet',      'Cukrová řepa', 'zelenina', 8, 14, 2400, 30, 6, 'tractor', { t: 'beet' }),
  zeli:      crop('zeli',      'Zelí',         'zelenina', 8, 8,  1500, 20, 5, 'tractor', { t: 'leafy', c: '#b7dd8a' }),
  dyne:      crop('dyne',      'Dýně',         'zelenina', 10, 12, 2400, 30, 6, 'tractor', { t: 'vine', c: '#f08a24' }),
  // ovoce z pole
  jahody:    crop('jahody',    'Jahody',       'ovoce',    4, 6,  900,  15, 3, 'tractor', { t: 'berry', c: '#e0283c' }),
  meloun:    crop('meloun',    'Meloun',       'ovoce',    9, 14, 2700, 34, 6, 'tractor', { t: 'vine', c: '#3f8a2e' }),
};
export const CROP_LIST = Object.values(CROPS).sort((a, b) => a.level - b.level || a.cost - b.cost);
export const CROP_CATS = { obili: 'Obilí a olejniny', zelenina: 'Zelenina', ovoce: 'Ovoce' };

// ovoce ze sadu (stromy a keře)
const fruit = (id, name, price, color) => ({ id, name, price, icon: id, color });
export const FRUITS = {
  jablko:  fruit('jablko',  'Jablko',  10, '#d9342b'),
  hruska:  fruit('hruska',  'Hruška',  14, '#c9c23a'),
  svestka: fruit('svestka', 'Švestka', 12, '#5b3f8f'),
  tresne:  fruit('tresne',  'Třešně',  18, '#b5122b'),
  merunka: fruit('merunka', 'Meruňka', 20, '#f2a03d'),
  visne:   fruit('visne',   'Višně',   16, '#8a1020'),
  broskev: fruit('broskev', 'Broskev', 24, '#f5a37a'),
  orech:   fruit('orech',   'Ořechy',  22, '#9a6c38'),
  maliny:  fruit('maliny',  'Maliny',  8,  '#d6335a'),
  rybiz:   fruit('rybiz',   'Rybíz',   9,  '#c41e3a'),
  angrest: fruit('angrest', 'Angrešt', 10, '#a8c84a'),
  boruvky: fruit('boruvky', 'Borůvky', 9,  '#3b4f9a'),
  hrozny:  fruit('hrozny',  'Hrozny',  16, '#6b2f7a'),
};

// stromy a keře do sadu: cost = sazenice, first = první úroda (s), regrow = další úroda (s), harvests = kolikrát plodí
const tree = (id, name, kind, fruitId, level, cost, first, regrow, yld, harvests, xp) =>
  ({ id, name, kind, fruit: fruitId, level, cost, first, regrow, yield: yld, harvests, xp, color: FRUITS[fruitId].color });
export const TREES = {
  maliny:  tree('maliny',  'Malinový keř',  'bush', 'maliny',  4, 30,  1200, 900,  3, 5, 2),
  rybiz:   tree('rybiz',   'Rybíz',         'bush', 'rybiz',   5, 35,  1500, 1080, 3, 5, 2),
  angrest: tree('angrest', 'Angrešt',       'bush', 'angrest', 6, 40,  1800, 1200, 3, 5, 3),
  boruvky: tree('boruvky', 'Borůvčí',       'bush', 'boruvky', 7, 50,  2100, 1500, 4, 5, 3),
  reva:    tree('reva',    'Vinná réva',    'bush', 'hrozny',  9, 90,  3600, 2700, 4, 6, 5),
  jablon:  tree('jablon',  'Jabloň',        'tree', 'jablko',  3, 40,  1800, 1200, 3, 4, 3),
  hrusen:  tree('hrusen',  'Hrušeň',        'tree', 'hruska',  4, 60,  2700, 1800, 3, 4, 4),
  svestka: tree('svestka', 'Švestka',       'tree', 'svestka', 5, 80,  3600, 2400, 4, 4, 5),
  tresen:  tree('tresen',  'Třešeň',        'tree', 'tresne',  6, 120, 5400, 3600, 4, 4, 6),
  visen:   tree('visen',   'Višeň',         'tree', 'visne',   7, 100, 4500, 3000, 4, 4, 6),
  merunka: tree('merunka', 'Meruňka',       'tree', 'merunka', 8, 160, 7200, 5400, 4, 5, 8),
  broskev: tree('broskev', 'Broskvoň',      'tree', 'broskev', 10, 200, 9000, 6000, 4, 5, 9),
  orech:   tree('orech',   'Ořešák',        'tree', 'orech',   11, 240, 10800, 7200, 5, 5, 10),
};
export const TREE_LIST = Object.values(TREES).sort((a, b) => a.level - b.level || a.cost - b.cost);

// výrobky: cena se dopočítá z receptu (suroviny × 1,2 + čas), aby byla ekonomika vyvážená
const P = (id, name) => ({ id, name, icon: id, price: 0 });
export const PRODUCTS = {
  krmivo_slepice: P('krmivo_slepice', 'Krmivo pro slepice'),
  krmivo_kravy:   P('krmivo_kravy', 'Krmivo pro krávy'),
  krmivo_prasata: P('krmivo_prasata', 'Krmivo pro prasata'),
  krmivo_ovce:    P('krmivo_ovce', 'Krmivo pro ovce'),
  vejce: P('vejce', 'Vejce'), mleko: P('mleko', 'Mléko'), maso: P('maso', 'Maso'), vlna: P('vlna', 'Vlna'),
  chleb: P('chleb', 'Chléb'), kolac: P('kolac', 'Koláč'), tresnovy_kolac: P('tresnovy_kolac', 'Třešňový koláč'),
  muffiny: P('muffiny', 'Borůvkové muffiny'), buchty: P('buchty', 'Buchty'), orechovy_kolac: P('orechovy_kolac', 'Ořechový koláč'),
  mouka: P('mouka', 'Mouka'),
  smetana: P('smetana', 'Smetana'), syr: P('syr', 'Sýr'), maslo: P('maslo', 'Máslo'),
  olej: P('olej', 'Řepkový olej'), sl_olej: P('sl_olej', 'Slunečnicový olej'),
  cukr: P('cukr', 'Cukr'),
  salat_mix: P('salat_mix', 'Zeleninový salát'), okurky: P('okurky', 'Kyselé okurky'), kecup: P('kecup', 'Kečup'),
  lecho: P('lecho', 'Lečo'), kysane_zeli: P('kysane_zeli', 'Kysané zelí'), kompot: P('kompot', 'Angreštový kompot'),
  hrachovka: P('hrachovka', 'Hrachová polévka'), dynovka: P('dynovka', 'Dýňová polévka'), broskve_sklo: P('broskve_sklo', 'Broskvový kompot'),
  dzus_mrkev: P('dzus_mrkev', 'Mrkvová šťáva'), dzus_jablko: P('dzus_jablko', 'Jablečný džus'), dzus_hruska: P('dzus_hruska', 'Hruškový džus'),
  dzus_visne: P('dzus_visne', 'Višňový džus'), most: P('most', 'Hroznový mošt'), napoj: P('napoj', 'Melounový nápoj'),
  povidla: P('povidla', 'Švestková povidla'), dzem_malina: P('dzem_malina', 'Malinový džem'), dzem_jahoda: P('dzem_jahoda', 'Jahodový džem'),
  marmelada: P('marmelada', 'Rybízová marmeláda'), dzem_merunka: P('dzem_merunka', 'Meruňkový džem'),
  klobasa: P('klobasa', 'Klobása'), uzene: P('uzene', 'Uzené maso'),
  klubko: P('klubko', 'Klubko vlny'), svetr: P('svetr', 'Svetr'), deka: P('deka', 'Vlněná deka'),
  slama: { id: 'slama', name: 'Sláma', icon: 'slama', price: 6 },
};

// výrobek = id receptu, vždy 1 kus; level = úroveň hráče
const R = (id, building, level, inp, time, xp) => ({ id, building, level, in: inp, time, xp });
export const RECIPES = {
  krmivo_slepice: R('krmivo_slepice', 'krmivarna', 2, { wheat: 2, corn: 1 }, 120, 1),
  krmivo_kravy:   R('krmivo_kravy',   'krmivarna', 4, { corn: 2, carrot: 1 }, 300, 2),
  krmivo_prasata: R('krmivo_prasata', 'krmivarna', 7, { potato: 2, corn: 1, salat: 1 }, 300, 3),
  krmivo_ovce:    R('krmivo_ovce',    'krmivarna', 9, { wheat: 2, zeli: 1, soy: 1 }, 360, 3),
  chleb:          R('chleb',          'pekarna', 2, { wheat: 3 }, 300, 3),
  kolac:          R('kolac',          'pekarna', 4, { wheat: 2, vejce: 2 }, 900, 6),
  tresnovy_kolac: R('tresnovy_kolac', 'pekarna', 7, { mouka: 2, tresne: 2, vejce: 1 }, 1200, 8),
  muffiny:        R('muffiny',        'pekarna', 8, { mouka: 1, boruvky: 2, vejce: 1 }, 900, 7),
  buchty:         R('buchty',         'pekarna', 9, { mouka: 2, cukr: 1, vejce: 1 }, 900, 7),
  orechovy_kolac: R('orechovy_kolac', 'pekarna', 12, { mouka: 2, orech: 2, cukr: 1 }, 1500, 10),
  mouka:          R('mouka',          'mlyn', 4, { wheat: 3 }, 240, 2),
  smetana:        R('smetana',        'mlekarna', 6, { mleko: 1 }, 600, 3),
  syr:            R('syr',            'mlekarna', 7, { mleko: 2 }, 1200, 6),
  maslo:          R('maslo',          'mlekarna', 8, { smetana: 2 }, 900, 6),
  olej:           R('olej',           'olejna', 6, { repka: 2 }, 600, 4),
  sl_olej:        R('sl_olej',        'olejna', 7, { sun: 3 }, 720, 5),
  cukr:           R('cukr',           'cukrovar', 8, { beet: 2 }, 600, 4),
  salat_mix:      R('salat_mix',      'konzervarna', 5, { salat: 2, rajce: 1, okurka: 1, redkvicka: 1 }, 300, 4),
  okurky:         R('okurky',         'konzervarna', 6, { okurka: 3, cesnek: 1 }, 900, 5),
  kecup:          R('kecup',          'konzervarna', 6, { rajce: 4, cibule: 1 }, 900, 5),
  lecho:          R('lecho',          'konzervarna', 7, { paprika: 2, rajce: 2, cibule: 1 }, 1200, 6),
  kysane_zeli:    R('kysane_zeli',    'konzervarna', 8, { zeli: 2, cibule: 1 }, 1200, 6),
  kompot:         R('kompot',         'konzervarna', 8, { angrest: 3, cukr: 1 }, 900, 6),
  hrachovka:      R('hrachovka',      'konzervarna', 9, { hrach: 2, potato: 1, cibule: 1 }, 1200, 7),
  dynovka:        R('dynovka',        'konzervarna', 10, { dyne: 1, cibule: 1, smetana: 1 }, 1200, 8),
  broskve_sklo:   R('broskve_sklo',   'konzervarna', 10, { broskev: 3, cukr: 1 }, 1200, 8),
  dzus_mrkev:     R('dzus_mrkev',     'dzusarna', 5, { carrot: 3 }, 480, 3),
  dzus_jablko:    R('dzus_jablko',    'dzusarna', 5, { jablko: 4 }, 600, 4),
  dzus_hruska:    R('dzus_hruska',    'dzusarna', 5, { hruska: 3 }, 600, 4),
  dzus_visne:     R('dzus_visne',     'dzusarna', 7, { visne: 3 }, 720, 5),
  most:           R('most',           'dzusarna', 9, { hrozny: 3 }, 900, 6),
  napoj:          R('napoj',          'dzusarna', 10, { meloun: 1, cukr: 1 }, 600, 6),
  povidla:        R('povidla',        'marmeladarna', 6, { svestka: 4 }, 900, 5),
  dzem_malina:    R('dzem_malina',    'marmeladarna', 8, { maliny: 3, cukr: 1 }, 900, 6),
  dzem_jahoda:    R('dzem_jahoda',    'marmeladarna', 8, { jahody: 3, cukr: 1 }, 900, 6),
  marmelada:      R('marmelada',      'marmeladarna', 8, { rybiz: 3, cukr: 1 }, 900, 6),
  dzem_merunka:   R('dzem_merunka',   'marmeladarna', 9, { merunka: 3, cukr: 1 }, 900, 7),
  klobasa:        R('klobasa',        'uzenarstvi', 8, { maso: 2, cesnek: 1 }, 1200, 7),
  uzene:          R('uzene',          'uzenarstvi', 9, { maso: 2 }, 1500, 7),
  klubko:         R('klubko',         'textilka', 10, { vlna: 2 }, 900, 7),
  svetr:          R('svetr',          'textilka', 11, { klubko: 2 }, 1800, 10),
  deka:           R('deka',           'textilka', 12, { klubko: 3 }, 2400, 12),
};

// zvířata: max = kolik se jich vejde do ohrady (úroveň ohrady přidává další)
export const ANIMALS = {
  slepice: { id: 'slepice', name: 'Slepice', acc: 'slepici', home: 'kurnik',   level: 3, cost: 20,  feed: 'krmivo_slepice', product: 'vejce', time: 600,  xp: 2, max: 3, icon: 'hen' },
  krava:   { id: 'krava',   name: 'Kráva',   acc: 'krávu',   home: 'kravin',   level: 5, cost: 60,  feed: 'krmivo_kravy',   product: 'mleko', time: 1800, xp: 4, max: 3, icon: 'cow' },
  prase:   { id: 'prase',   name: 'Prase',   acc: 'prase',   home: 'prasecak', level: 7, cost: 90,  feed: 'krmivo_prasata', product: 'maso',  time: 2400, xp: 5, max: 3, icon: 'pig' },
  ovce:    { id: 'ovce',    name: 'Ovce',    acc: 'ovci',    home: 'ovcin',    level: 9, cost: 120, feed: 'krmivo_ovce',    product: 'vlna',  time: 3000, xp: 6, max: 3, icon: 'sheep' },
};
export const ANIMAL_LIST = Object.values(ANIMALS);

// ceny výrobků a živočišných produktů dopočítat z receptů
{
  const base = id => (CROPS[id] || FRUITS[id] || PRODUCTS[id]).price;
  let left = Object.values(RECIPES);
  for (let pass = 0; left.length && pass < 20; pass++) {
    left = left.filter(r => {
      if (Object.keys(r.in).some(id => !base(id))) return true;
      const inputs = Object.entries(r.in).reduce((n, [id, q]) => n + base(id) * q, 0);
      PRODUCTS[r.id].price = Math.round(inputs * 1.2 + r.time / 60 + 2);
      return false;
    });
    for (const a of ANIMAL_LIST) {
      if (!PRODUCTS[a.product].price && PRODUCTS[a.feed].price) {
        PRODUCTS[a.product].price = Math.round(PRODUCTS[a.feed].price * 1.3 + a.time / 60 * 0.5 + 3);
      }
    }
  }
}

export const ITEMS = { ...CROPS, ...PRODUCTS, ...FRUITS };
export const ITEM_LIST = Object.values(ITEMS);

// type: main, storage, garage (stodola), dealer (prodejna strojů), stall (stánek), factory, pen, orchard, bigfield, deco
// level = úroveň hráče, st = potřebná úroveň statku; max 0 = bez omezení
const B = (id, name, type, level, st, cost, w, h, xp, max, icon, extra = {}) => ({ id, name, type, level, st, cost, w, h, xp, max, icon, ...extra });
export const BUILDINGS = {
  statek:       B('statek', 'Statek', 'main', 1, 0, 0, 3, 3, 0, 1, 'house'),
  sklad:        B('sklad', 'Sklad', 'storage', 1, 0, 0, 2, 2, 0, 1, 'barn'),
  prodejna:     B('prodejna', 'Prodejna strojů', 'dealer', 1, 0, 0, 2, 2, 0, 1, 'shop'),
  stanek:       B('stanek', 'Stánek', 'stall', 1, 0, 0, 2, 2, 0, 1, 'stall'),
  stodola:      B('stodola', 'Stodola na stroje', 'garage', 5, 2, 300, 3, 2, 10, 1, 'garage'),
  sad:          B('sad', 'Sad', 'orchard', 3, 1, 0, 1, 1, 1, 0, 'tree', { info: 'Políčko pro ovocný strom nebo keř.' }),
  velkepole:    B('velkepole', 'Velké pole', 'bigfield', 5, 2, 0, 4, 4, 5, 0, 'field', { info: 'Pole, na kterém pracují stroje. Velikost si zvolíš.' }),
  krmivarna:    B('krmivarna', 'Krmivárna', 'factory', 2, 1, 40, 2, 2, 4, 1, 'krmivo_slepice', { color: '#6f9bd1' }),
  pekarna:      B('pekarna', 'Pekárna', 'factory', 2, 1, 60, 2, 2, 5, 1, 'chleb', { color: '#d9734e' }),
  kurnik:       B('kurnik', 'Kurník', 'pen', 3, 1, 50, 2, 2, 5, 1, 'hen', { animal: 'slepice' }),
  mlyn:         B('mlyn', 'Mlýn', 'factory', 4, 2, 120, 2, 2, 6, 1, 'mouka', { color: '#e8dcc0' }),
  kravin:       B('kravin', 'Kravín', 'pen', 5, 2, 150, 3, 3, 8, 1, 'cow', { animal: 'krava' }),
  konzervarna:  B('konzervarna', 'Konzervárna', 'factory', 5, 2, 180, 2, 2, 8, 1, 'okurky', { color: '#7fb07a' }),
  dzusarna:     B('dzusarna', 'Džusárna', 'factory', 5, 2, 200, 2, 2, 8, 1, 'dzus_jablko', { color: '#f2b84a' }),
  mlekarna:     B('mlekarna', 'Mlékárna', 'factory', 6, 3, 200, 2, 2, 10, 1, 'syr', { color: '#9fb7c9' }),
  olejna:       B('olejna', 'Olejna', 'factory', 6, 3, 250, 2, 2, 8, 1, 'olej', { color: '#d9c25a' }),
  marmeladarna: B('marmeladarna', 'Marmeládárna', 'factory', 6, 3, 260, 2, 2, 9, 1, 'dzem_jahoda', { color: '#d9607a' }),
  prasecak:     B('prasecak', 'Prasečák', 'pen', 7, 3, 260, 3, 3, 9, 1, 'pig', { animal: 'prase' }),
  cukrovar:     B('cukrovar', 'Cukrovar', 'factory', 8, 4, 400, 2, 2, 10, 1, 'cukr', { color: '#b9c7d6' }),
  uzenarstvi:   B('uzenarstvi', 'Uzenářství', 'factory', 8, 4, 420, 2, 2, 10, 1, 'klobasa', { color: '#a5664a' }),
  ovcin:        B('ovcin', 'Ovčín', 'pen', 9, 5, 450, 3, 3, 10, 1, 'sheep', { animal: 'ovce' }),
  textilka:     B('textilka', 'Textilka', 'factory', 10, 5, 600, 2, 2, 12, 1, 'klubko', { color: '#b48ad0' }),
  ker:          B('ker', 'Keř', 'deco', 1, 0, 10, 1, 1, 1, 0, 'bush'),
  kvetiny:      B('kvetiny', 'Záhon květin', 'deco', 2, 0, 15, 1, 1, 1, 0, 'flowers'),
  lavicka:      B('lavicka', 'Lavička', 'deco', 3, 0, 30, 1, 1, 2, 0, 'bench'),
  jablon:       B('jablon', 'Kvetoucí strom', 'deco', 4, 0, 40, 1, 1, 2, 0, 'blossom'),
  fontana:      B('fontana', 'Fontána', 'deco', 6, 0, 150, 1, 1, 5, 0, 'fountain'),
};
export const BUILDING_LIST = Object.values(BUILDINGS);

// stroje a náčiní z prodejny; speed = políček za minutu; vozidla (tractor, combine) potřebují místo ve stodole
export const MACHINES = {
  brazda60:  { id: 'brazda60',  name: 'Traktor Brázda 60',  type: 'tractor', level: 5,  cost: 250,  speed: 6,  color: '#c8452d', icon: 'tractor', info: 'Seje a orá na velkém poli, sklízí zeleninu. Zaseje i všechna malá pole.' },
  klas4:     { id: 'klas4',     name: 'Kombajn Klas 4',     type: 'combine', level: 6,  cost: 600,  speed: 6,  color: '#4f9a3a', icon: 'combine', info: 'Sklízí obilí, olejniny a hrách. Sklidí i všechna malá pole.' },
  brazda120: { id: 'brazda120', name: 'Traktor Brázda 120', type: 'tractor', level: 9,  cost: 900,  speed: 12, color: '#2f6fb5', icon: 'tractor', info: 'Dvakrát rychlejší traktor.' },
  klas8:     { id: 'klas8',     name: 'Kombajn Klas 8',     type: 'combine', level: 11, cost: 1800, speed: 12, color: '#d9b43b', icon: 'combine', info: 'Dvakrát rychlejší kombajn.' },
  pluh:      { id: 'pluh',      name: 'Pluh',               type: 'plow',    level: 6,  cost: 300,  speed: 0,  color: '#8a8f96', icon: 'pluh',  info: 'Zorané velké pole dá o 50 % větší úrodu. Táhne ho traktor.' },
  secka:     { id: 'secka',     name: 'Secí stroj',         type: 'seeder',  level: 7,  cost: 500,  speed: 0,  color: '#3f7fbf', icon: 'secka', info: 'Traktor s ním seje dvakrát rychleji.' },
  lis:       { id: 'lis',       name: 'Lis na balíky',      type: 'baler',   level: 8,  cost: 700,  speed: 0,  color: '#d9b43b', icon: 'lis',   info: 'Po sklizni obilí slisuje slámu do balíků. Táhne ho traktor.' },
  kolecko:   { id: 'kolecko',   name: 'Kolečko',            type: 'helper',  level: 3,  cost: 150,  speed: 0,  color: '#8a8f96', icon: 'kolecko', info: 'Pomocník s ním obslouží o 2 políčka víc najednou.' },
  motyka:    { id: 'motyka',    name: 'Motyka a konev',     type: 'helper',  level: 4,  cost: 250,  speed: 0,  color: '#8a8f96', icon: 'motyka', info: 'Pomocník pracuje dvakrát častěji.' },
};
export const MACHINE_LIST = Object.values(MACHINES);

// ---------- odměny a úkoly ----------
export const DAILY = [
  { coins: 20 }, { coins: 30 }, { coins: 40 }, { coins: 60 }, { coins: 80 }, { coins: 100 }, { coins: 200, xp: 10 },
];
export const ACHIEVEMENTS = [
  { id: 'harvest', name: 'Sklízeč',        stat: 'harvest', tiers: [50, 500, 5000],   coins: [50, 250, 1000], icon: 'wheat',  text: 'Sklidit plodin' },
  { id: 'produce', name: 'Výrobce',        stat: 'produce', tiers: [20, 200, 2000],   coins: [60, 300, 1200], icon: 'chleb',  text: 'Vyrobit výrobků' },
  { id: 'animal',  name: 'Chovatel',       stat: 'animal',  tiers: [20, 200, 2000],   coins: [60, 300, 1200], icon: 'vejce',  text: 'Sebrat vajec a mléka' },
  { id: 'fruit',   name: 'Sadař',          stat: 'fruit',   tiers: [30, 300, 3000],   coins: [60, 300, 1200], icon: 'jablko', text: 'Sklidit ovoce' },
  { id: 'orders',  name: 'Dodavatel',      stat: 'orders',  tiers: [10, 100, 500],    coins: [80, 400, 1500], icon: 'truck',  text: 'Doručit zakázek' },
  { id: 'sold',    name: 'Obchodník',      stat: 'sold',    tiers: [500, 5000, 50000], coins: [50, 300, 1500], icon: 'coin',  text: 'Vydělat mincí výkupem' },
  { id: 'jobs',    name: 'Strojník',       stat: 'jobs',    tiers: [5, 50, 300],      coins: [80, 400, 1500], icon: 'tractor', text: 'Prací strojů na velkém poli' },
];
const STAT_KEYS = ['harvest', 'produce', 'animal', 'fruit', 'orders', 'sold', 'jobs'];

// výkupní cena se mění každé 4 hodiny (0,7× až 1,4×), stejně na serveru i v prohlížeči
export const MARKET_PERIOD = 4 * 3600 * 1000;
export function marketMult(id, now) {
  const period = Math.floor(now / MARKET_PERIOD);
  let h = 2166136261;
  for (const ch of id + ':' + period) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0; }
  return Math.round((0.7 + (h % 1000) / 1000 * 0.7) * 100) / 100;
}
// výkupna ve skladu platí polovinu ceny (× tržní výkyv); lépe platí stánek a nejlépe zakázky
export const sellPrice = (id, now) => Math.max(1, Math.round(ITEMS[id].price * 0.5 * marketMult(id, now)));
export const nextMarketChange = now => (Math.floor(now / MARKET_PERIOD) + 1) * MARKET_PERIOD;

// den pro denní odměnu (středoevropský čas, zjednodušeně UTC+1)
export const dayKey = now => new Date(now + 3600000).toISOString().slice(0, 10);
export const MACHINE_TYPE_NAME = { tractor: 'traktor', combine: 'kombajn', plow: 'pluh', seeder: 'secí stroj', baler: 'lis', helper: 'náčiní' };
export const isVehicle = model => ['tractor', 'combine'].includes(MACHINES[model].type);
export const MACHINE_TYPE_NAME2 = { helper: 'náčiní pro pomocníka' };

// celkové XP potřebné pro dosažení úrovně (index = úroveň)
export const LEVEL_XP = [0, 0, 10, 25, 45, 70, 100, 140, 190, 250, 320, 400, 500, 620, 760, 920, 1100, 1300, 1550, 1800, 2100];
export const MAX_LEVEL = LEVEL_XP.length - 1;

function own(table, id) {
  return typeof id === 'string' && Object.hasOwn(table, id) ? table[id] : null;
}
export const getCrop = id => own(CROPS, id);
export const getItem = id => own(ITEMS, id);
export const getBuilding = id => own(BUILDINGS, id);
export const getRecipe = id => own(RECIPES, id);
const isInt = v => Number.isInteger(v);

// ---------- stav ----------
export function newFarm(now) {
  return normalize({
    v: RULES_VERSION,
    coins: START_COINS,
    xp: 0,
    level: 1,
    silo: {},
    siloCap: SILO_START,
    plots: [],            // 6 polí si hráč postaví sám, zdarma
    objects: [{ id: 1, kind: 'statek', x: MAIN_POS[0], y: MAIN_POS[1] }],
    machines: [],         // stroje v garáži: { id, model }
    nextId: 2,
    pending: ['sklad'],   // budovy zdarma, které hráč ještě neumístil
    created: now,
    seed: (now % 2147483646) + 1,
  });
}

// doplní chybějící části u starších farem
export function normalize(farm) {
  if (!Array.isArray(farm.objects)) farm.objects = [];
  if (!farm.nextId) farm.nextId = 1;
  if (!farm.siloCap) farm.siloCap = SILO_START;
  if (!Array.isArray(farm.pending)) farm.pending = [];
  if (!Array.isArray(farm.machines)) farm.machines = [];
  if (!Array.isArray(farm.land)) farm.land = [];
  if (!farm.stats) farm.stats = {};
  for (const k of STAT_KEYS) if (!farm.stats[k]) farm.stats[k] = 0;
  if (!farm.ach) farm.ach = {};
  if (!farm.daily) farm.daily = { day: '', streak: 0 };
  // v3/v4: traktor a kombajn stály na mapě – převést do garáže
  const OLD = { traktor: 'brazda60', kombajn: 'klas4' };
  for (const o of farm.objects.filter(o => OLD[o.kind])) {
    if (!farm.machines.some(m => m.model === OLD[o.kind])) farm.machines.push({ id: o.id, model: OLD[o.kind] });
  }
  farm.objects = farm.objects.filter(o => !OLD[o.kind]);
  if (!farm.objects.some(o => o.kind === 'statek')) {
    // starší farma: statek doprostřed, nebo na nejbližší volné místo
    let pos = fits(farm, MAIN_POS[0], MAIN_POS[1], 3, 3) ? MAIN_POS : null;
    for (let r = 1; !pos && r < GRID_W; r++) {
      for (let y = MAIN_POS[1] - r; !pos && y <= MAIN_POS[1] + r; y++) {
        for (let x = MAIN_POS[0] - r; !pos && x <= MAIN_POS[0] + r; x++) if (fits(farm, x, y, 3, 3)) pos = [x, y];
      }
    }
    if (pos) farm.objects.unshift({ id: farm.nextId++, kind: 'statek', x: pos[0], y: pos[1] });
  }
  if (!farm.objects.some(o => o.kind === 'sklad') && !farm.pending.includes('sklad')) farm.pending.push('sklad');
  for (const o of farm.objects) if (!o.lvl && UP_BASE[BUILDINGS[o.kind].type]) o.lvl = 1;
  if (!farm.objects.some(o => o.kind === 'prodejna')) placeNear(farm, 'prodejna', 3, 8);
  if (!farm.objects.some(o => o.kind === 'stanek')) placeNear(farm, 'stanek', 12, 3);
  if (farm.machines.some(m => isVehicle(m.model)) && !farm.objects.some(o => o.kind === 'stodola') && !farm.pending.includes('stodola')) farm.pending.push('stodola');
  if (farm.helper === undefined) farm.helper = null;
  if (!farm.seed) farm.seed = ((farm.created || 1) % 2147483646) + 1;
  if (!Array.isArray(farm.orders)) farm.orders = [];
  while (farm.orders.length < ORDER_SLOTS) farm.orders.push(genOrder(farm, 0));
  farm.v = RULES_VERSION;
  return farm;
}

export function levelForXp(xp) {
  let l = 1;
  while (l < MAX_LEVEL && xp >= LEVEL_XP[l + 1]) l++;
  return l;
}

// { cur, need } – kolik XP v rámci aktuální úrovně
export function levelProgress(farm) {
  if (farm.level >= MAX_LEVEL) return { cur: 1, need: 1 };
  const base = LEVEL_XP[farm.level];
  return { cur: farm.xp - base, need: LEVEL_XP[farm.level + 1] - base };
}

function addXp(farm, n) {
  const before = farm.level;
  farm.xp += n;
  farm.level = levelForXp(farm.xp);
  return farm.level > before ? farm.level : 0;
}

export function siloUsed(farm) {
  let n = 0;
  for (const k in farm.silo) n += farm.silo[k];
  return n;
}
export const siloFree = farm => farm.siloCap - siloUsed(farm);
export const siloUpgradePrice = farm => 80 * ((farm.siloCap - SILO_START) / SILO_STEP + 1);

const ANIMAL_PRODUCTS = new Set(['vejce', 'mleko', 'maso', 'vlna']);
function statOf(id) {
  if (CROPS[id] || id === 'slama') return 'harvest';
  if (FRUITS[id]) return 'fruit';
  if (ANIMAL_PRODUCTS.has(id)) return 'animal';
  return 'produce';
}
function addStat(farm, key, n) { farm.stats[key] = (farm.stats[key] || 0) + n; }
function addItem(farm, id, n) {
  farm.silo[id] = (farm.silo[id] || 0) + n;
  addStat(farm, statOf(id), n);
}
function takeItem(farm, id, n) {
  farm.silo[id] -= n;
  if (!farm.silo[id]) delete farm.silo[id];
}
export const have = (farm, id) => farm.silo[id] || 0;
export function hasInputs(farm, recipe) {
  return Object.entries(recipe.in).every(([id, n]) => have(farm, id) >= n);
}

export function maxPlots(level) {
  return PLOTS_PER_LEVEL * level;
}

export function plotPrice(farm) {
  const n = farm.plots.length;
  return n < FREE_PLOTS ? 0 : 15 + 5 * (n - FREE_PLOTS);
}

export function maxOrchards(level) {
  return level < 3 ? 0 : 2 * (level - 2);
}
export function orchardPrice(farm) {
  return 30 + 20 * countKind(farm, 'sad');
}

// stav stromu v sadu: 'empty' | 'growing' | 'ready' | 'dead'
export function treeState(obj, now) {
  if (!obj.tree) return { state: 'empty', progress: 0, left: 0 };
  if (obj.dead) return { state: 'dead', progress: 1, left: 0 };
  const t = TREES[obj.tree];
  if (now >= obj.readyAt) return { state: 'ready', progress: 1, left: 0 };
  const total = (obj.left === t.harvests ? t.first : t.regrow) * 1000;
  return { state: 'growing', progress: Math.max(0, 1 - (obj.readyAt - now) / total), left: Math.ceil((obj.readyAt - now) / 1000) };
}

// ---------- stroje a velké pole ----------
export const maxBigFields = level => (level < 5 ? 0 : 1 + Math.floor((level - 5) / 3));
export const hasMachine = (farm, type) => farm.machines.some(m => MACHINES[m.model].type === type);
export const findMachine = (farm, id) => farm.machines.find(m => m.id === id) || null;
export function machineJob(farm, id, now) {
  return farm.objects.find(o => o.job && o.job.m === id && now < o.job.end) || null;
}
// nejrychlejší volný stroj daného typu
export function freeMachine(farm, type, now) {
  return farm.machines
    .filter(m => MACHINES[m.model].type === type && !machineJob(farm, m.id, now))
    .sort((a, b) => MACHINES[b.model].speed - MACHINES[a.model].speed)[0] || null;
}
export const jobSeconds = (cells, model) => Math.ceil(cells / MACHINES[model].speed * 60);

// stav velkého pole: empty | sowing | growing | ready | harvesting | unload
export function fieldState(o, now) {
  const j = o.job;
  if (j && now < j.end) {
    const map = { sow: 'sowing', harvest: 'harvesting', plow: 'plowing', bale: 'baling' };
    return { state: map[j.type], progress: (now - j.start) / (j.end - j.start), left: Math.ceil((j.end - now) / 1000) };
  }
  if (o.load && o.load.qty > 0) return { state: 'unload', progress: 1, left: 0, stock: o.load.qty, item: o.load.item };
  if (o.crop) {
    if (now >= o.readyAt) return { state: 'ready', progress: 1, left: 0 };
    const total = o.readyAt - j.end;
    return { state: 'growing', progress: Math.max(0, (now - j.end) / total), left: Math.ceil((o.readyAt - now) / 1000) };
  }
  return { state: 'empty', progress: 0, left: 0, soil: o.soil || 'raw', straw: !!o.straw };
}
export const hasTool = (farm, type) => farm.machines.some(m => MACHINES[m.model].type === type);
export function fieldYield(o) {
  return Math.round(o.w * o.h * CROPS[o.crop].yield * (o.mult || 1));
}

// ---------- úrovně budov ----------
export const MAX_BLD_LEVEL = 10;
// úroveň hráče potřebná pro úroveň statku (index = úroveň statku)
export const STATEK_LEVELS = [0, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19];
const UP_BASE = { main: 300, storage: 120, garage: 180, dealer: 160, stall: 140, factory: 110, pen: 110 };
export const UPGRADABLE = Object.keys(UP_BASE);
export const objLevel = o => o.lvl || 1;
export function statekLevel(farm) {
  const st = farm.objects.find(o => o.kind === 'statek');
  return st ? objLevel(st) : 1;
}
export const speedMult = o => 1 - 0.05 * (objLevel(o) - 1);          // −5 % času za úroveň
export const queueSize = o => QUEUE_SIZE + Math.floor((objLevel(o) - 1) / 3);
export const penMax = o => ANIMALS[BUILDINGS[o.kind].animal].max + Math.floor((objLevel(o) - 1) / 3);
export const garageSlots = farm => farm.objects.filter(o => o.kind === 'stodola').reduce((n, o) => n + 1 + objLevel(o), 0);
export const vehicleCount = farm => farm.machines.filter(m => isVehicle(m.model)).length;
export function dealerDiscount(farm) {
  const d = farm.objects.find(o => o.kind === 'prodejna');
  return d ? 0.03 * (objLevel(d) - 1) : 0;
}
export const machinePrice = (farm, id) => Math.round(MACHINES[id].cost * (1 - dealerDiscount(farm)));
export const orderBonus = farm => 1 + 0.03 * (statekLevel(farm) - 1);

function hashStr(str) {
  let h = 2166136261;
  for (const ch of str) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0; }
  return h;
}
function seeded(str) {
  let x = hashStr(str) % 2147483646 + 1;
  return () => (x = (x * 16807) % 2147483647) / 2147483647;
}

// cena vylepšení budovy na další úroveň (stejná na serveru i v prohlížeči)
export function upgradeCost(o) {
  const d = BUILDINGS[o.kind];
  if (!UP_BASE[d.type]) return null;
  const L = objLevel(o);
  if (L >= MAX_BLD_LEVEL) return null;
  const coins = Math.round(UP_BASE[d.type] * Math.pow(L, 1.5));
  const tier = Math.min(MAX_LEVEL, 1 + Math.round(L * 1.6));
  const pool = orderableItems(tier).filter(id => ITEMS[id].price <= coins);
  const r = seeded(o.kind + ':' + L);
  const k = Math.min(pool.length, L < 4 ? 2 : 3);
  const items = [];
  const left = [...pool];
  for (let i = 0; i < k; i++) {
    const id = left.splice(Math.floor(r() * left.length), 1)[0];
    items.push({ item: id, qty: Math.max(2, Math.min(40, Math.round(coins * 0.5 / k / ITEMS[id].price))) });
  }
  return { level: L + 1, coins, items, player: d.type === 'main' ? STATEK_LEVELS[L + 1] : 0 };
}

// co přinese další úroveň (text pro panel)
export function upgradeEffect(o) {
  const d = BUILDINGS[o.kind], L = objLevel(o) + 1;
  switch (d.type) {
    case 'main': return `odemkne budovy pro statek úrovně ${L}, zakázky +${3 * (L - 1)} % mincí`;
    case 'storage': return 'sklad +40 míst';
    case 'garage': return `místo pro ${1 + L} strojů`;
    case 'dealer': return `stroje o ${3 * (L - 1)} % levněji`;
    case 'stall': return 'víc nabídek a lepší ceny';
    case 'factory': return `výroba o ${5 * (L - 1)} % rychlejší${(L - 1) % 3 === 0 ? ', +1 místo ve frontě' : ''}`;
    case 'pen': return `zvířata o ${5 * (L - 1)} % rychlejší${(L - 1) % 3 === 0 ? ', +1 místo v ohradě' : ''}`;
  }
  return '';
}

// sklizeň jednoho malého pole (s 8% šancí na dvojitou „bohatou úrodu“)
function harvestPlot(farm, p) {
  const c = CROPS[p.crop];
  const bonus = rnd(farm) < 0.08 && siloFree(farm) >= c.yield * 2;
  const qty = bonus ? c.yield * 2 : c.yield;
  addItem(farm, c.id, qty);
  p.crop = null;
  p.planted = 0;
  return qty;
}

// ---------- pomocník ----------
export const HELPER_PLANS = [{ h: 1, cost: 120 }, { h: 4, cost: 400 }, { h: 8, cost: 700 }];
export const HELPER_LEVEL = 3;
export const helperInterval = farm => (hasTool(farm, 'helper') && farm.machines.some(m => m.model === 'motyka') ? 10 : 20);
export function helperCapacity(farm) {
  return 2 + (farm.machines.some(m => m.model === 'kolecko') ? 2 : 0) + (farm.helper && farm.helper.tractor && hasMachine(farm, 'tractor') ? 3 : 0);
}
export const helperActive = (farm, now) => !!farm.helper && now < farm.helper.until;

// pomocník pracuje v pravidelných kolech; dopočítá se vždy až do „teď“ (stejně na serveru i v prohlížeči)
export function runHelper(farm, now) {
  const h = farm.helper;
  if (!h) return [];
  const end = Math.min(now, h.until);
  const iv = helperInterval(farm) * 1000;
  const touched = [];
  let t = h.last + iv;
  for (let guard = 0; t <= end && guard < 6000; guard++, t += iv) {
    let cap = helperCapacity(farm);
    const plots = [...farm.plots].sort((a, b) => a.y - b.y || a.x - b.x);
    for (const p of plots) {
      if (cap <= 0) break;
      if (p.crop && plotState(p, t).state === 'ready' && siloFree(farm) >= CROPS[p.crop].yield) {
        const c = CROPS[p.crop];
        harvestPlot(farm, p);
        addXp(farm, c.xp);
        h.n = (h.n || 0) + 1; cap--; touched.push([p.x, p.y]);
      }
    }
    const c = h.crop && getCrop(h.crop);
    if (c && farm.level >= c.level) {
      for (const p of plots) {
        if (cap <= 0 || farm.coins < c.cost) break;
        if (!p.crop) {
          farm.coins -= c.cost;
          p.crop = c.id; p.planted = t;
          h.n = (h.n || 0) + 1; cap--; touched.push([p.x, p.y]);
        }
      }
    }
    h.last = t;
  }
  return touched;
}

// ---------- stánek ----------
export const STALL_PERIOD = 2 * 3600 * 1000;
export function stallOffers(farm, now) {
  const period = Math.floor(now / STALL_PERIOD);
  const stall = farm.objects.find(o => o.kind === 'stanek');
  const L = stall ? objLevel(stall) : 1;
  const lv = farm.stall && farm.stall.p === period ? farm.stall.lv : farm.level;
  const r = seeded(`${farm.created}:${period}:${L}`);
  const pool = orderableItems(lv);
  const pick = n => { const left = [...pool], out = []; for (let i = 0; i < n && left.length; i++) out.push(left.splice(Math.floor(r() * left.length), 1)[0]); return out; };
  const buy = pick(4 + Math.floor((L - 1) / 3)).map(id => ({
    item: id, qty: 3 + Math.floor(r() * (ITEMS[id].price < 20 ? 8 : 4)),
    price: Math.ceil(ITEMS[id].price * (1.6 - 0.03 * (L - 1))),
  }));
  const sell = pick(3).map(id => ({
    item: id, qty: 5 + Math.floor(r() * 11),
    price: Math.max(1, Math.round(ITEMS[id].price * (0.7 + 0.02 * (L - 1)))),
  }));
  return { period, buy, sell, next: (period + 1) * STALL_PERIOD };
}
function stallState(farm, now) {
  const period = Math.floor(now / STALL_PERIOD);
  if (!farm.stall || farm.stall.p !== period) farm.stall = { p: period, lv: farm.level, b: {}, s: {} };
  return farm.stall;
}
export function stallLeft(farm, now, kind, i, total) {
  const period = Math.floor(now / STALL_PERIOD);
  const used = farm.stall && farm.stall.p === period ? (farm.stall[kind][i] || 0) : 0;
  return total - used;
}

// ---------- automatické budovy ----------
function placeNear(farm, kind, px, py) {
  const { w, h } = BUILDINGS[kind];
  for (let r = 0; r < 20; r++) {
    for (let y = py - r; y <= py + r; y++) {
      for (let x = px - r; x <= px + r; x++) {
        if (Math.max(Math.abs(x - px), Math.abs(y - py)) !== r) continue;
        if (fits(farm, x, y, w, h)) { farm.objects.push({ id: farm.nextId++, kind, x, y, lvl: 1 }); return true; }
      }
    }
  }
  return false;
}

// ---------- zakázky ----------
// deterministický generátor (stejný výsledek na serveru i v prohlížeči)
function rnd(farm) {
  farm.seed = (farm.seed * 16807) % 2147483647;
  return (farm.seed - 1) / 2147483646;
}

// co hráč na své úrovni umí získat
export function orderableItems(level) {
  const out = CROP_LIST.filter(c => c.level <= level).map(c => c.id);
  for (const r of Object.values(RECIPES)) if (r.level <= level && BUILDINGS[r.building].level <= level) out.push(r.id);
  for (const a of ANIMAL_LIST) if (a.level <= level) out.push(a.product);
  for (const t of TREE_LIST) if (t.level <= level) out.push(t.fruit);
  return [...new Set(out)];
}

function genOrder(farm, readyAt) {
  const pool = orderableItems(farm.level);
  const kinds = Math.min(pool.length, 1 + Math.floor(rnd(farm) * Math.min(3, 1 + farm.level / 3)));
  const items = [];
  const left = [...pool];
  for (let k = 0; k < kinds; k++) {
    const id = left.splice(Math.floor(rnd(farm) * left.length), 1)[0];
    const it = ITEMS[id];
    const maxQ = it.price <= 5 ? 6 : it.price <= 15 ? 4 : it.price <= 30 ? 3 : 2;
    items.push({ item: id, qty: 1 + Math.floor(rnd(farm) * maxQ) });
  }
  const value = items.reduce((n, x) => n + ITEMS[x.item].price * x.qty, 0);
  return {
    items,
    coins: Math.round(value * (1.3 + rnd(farm) * 0.4) * orderBonus(farm)) + 2,   // o 30–70 % víc než hodnota zboží
    xp: Math.max(1, Math.round(value / 6)),
    readyAt,
  };
}

export const orderReady = (o, now) => now >= o.readyAt;
export const canDeliver = (farm, o) => o.items.every(x => have(farm, x.item) >= x.qty);


export function findPlot(farm, x, y) {
  return farm.plots.find(p => p.x === x && p.y === y) || null;
}

export function findObject(farm, id) {
  return farm.objects.find(o => o.id === id) || null;
}

// objekt, který zabírá políčko x,y
// velikost objektu (velké pole má vlastní)
export function objSize(o) {
  const d = BUILDINGS[o.kind];
  return { w: o.w || d.w, h: o.h || d.h };
}

export function objectAt(farm, x, y) {
  for (const o of farm.objects) {
    const d = objSize(o);
    if (x >= o.x && x < o.x + d.w && y >= o.y && y < o.y + d.h) return o;
  }
  return null;
}

export function countKind(farm, kind) {
  return farm.objects.filter(o => o.kind === kind).length;
}

// je místo volné? (ignoreId = objekt, který se právě přesouvá)
export function fits(farm, x, y, w, h, ignoreId = 0) {
  if (!isInt(x) || !isInt(y) || !isInt(w) || !isInt(h)) return false;
  for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (!landOwned(farm, xx, yy)) return false;
  for (const p of farm.plots) if (p.x >= x && p.x < x + w && p.y >= y && p.y < y + h) return false;
  for (const o of farm.objects) {
    if (o.id === ignoreId) continue;
    const d = objSize(o);
    if (o.x < x + w && x < o.x + d.w && o.y < y + h && y < o.y + d.h) return false;
  }
  return true;
}

// stav pole: 'empty' | 'growing' | 'ready'; progress 0..1; left = zbývající sekundy
export function plotState(plot, now) {
  if (!plot || !plot.crop) return { state: 'empty', progress: 0, left: 0 };
  const c = CROPS[plot.crop];
  const total = c.time * 1000;
  const elapsed = Math.max(0, now - plot.planted);
  if (elapsed >= total) return { state: 'ready', progress: 1, left: 0 };
  return { state: 'growing', progress: elapsed / total, left: Math.ceil((total - elapsed) / 1000) };
}

// fronta výroby: [{ r, start, end, state: 'waiting'|'working'|'done', progress, left }]
export function queueState(obj, now) {
  return (obj.queue || []).map(q => {
    const time = q.d || RECIPES[q.r].time * 1000;
    const start = q.end - time;
    if (now >= q.end) return { ...q, state: 'done', progress: 1, left: 0 };
    if (now < start) return { ...q, state: 'waiting', progress: 0, left: Math.ceil((q.end - now) / 1000) };
    return { ...q, state: 'working', progress: (now - start) / time, left: Math.ceil((q.end - now) / 1000) };
  });
}

// stav zvířete: 'hungry' | 'eating' | 'ready'
export function animalState(animal, def, now) {
  if (!animal.fed) return { state: 'hungry', progress: 0, left: 0 };
  const total = animal.dur || def.time * 1000;
  const el = now - animal.fed;
  if (el >= total) return { state: 'ready', progress: 1, left: 0 };
  return { state: 'eating', progress: Math.max(0, el / total), left: Math.ceil((total - el) / 1000) };
}

// souhrn pro budovu (pro bubliny nad budovou)
export function objectStatus(obj, now, farm) {
  const d = BUILDINGS[obj.kind];
  if (d.type === 'bigfield') {
    const st = fieldState(obj, now).state;
    return { done: st === 'ready' || st === 'unload' ? 1 : 0, busy: st === 'sowing' || st === 'harvesting' };
  }
  if (d.type === 'orchard') {
    const st = treeState(obj, now).state;
    return { done: st === 'ready' ? 1 : 0, dead: st === 'dead' };
  }
  if (d.type === 'main' && farm) {
    return { done: farm.orders.filter(o => orderReady(o, now) && canDeliver(farm, o)).length };
  }
  if (d.type === 'factory') {
    const q = queueState(obj, now);
    return { done: q.filter(x => x.state === 'done').length, busy: q.some(x => x.state === 'working') };
  }
  if (d.type === 'pen') {
    const a = ANIMALS[d.animal];
    const st = (obj.animals || []).map(x => animalState(x, a, now).state);
    return { done: st.filter(s => s === 'ready').length, hungry: st.filter(s => s === 'hungry').length, busy: st.includes('eating') };
  }
  return {};
}

function fail(code) { return { ok: false, error: code }; }

export const ERRORS = {
  bad_action: 'Neznámá akce.',
  no_plot: 'Tady není pole.',
  not_empty: 'Pole už je osázené.',
  not_ready: 'Ještě to není hotové.',
  locked: 'Tohle odemkneš na vyšší úrovni.',
  no_coins: 'Nemáš dost mincí.',
  silo_full: 'Sklad je plný – něco prodej nebo ho rozšiř.',
  occupied: 'Tohle místo je obsazené.',
  out_of_farm: 'Tady už farma končí.',
  max_plots: 'Víc polí odemkneš na vyšší úrovni.',
  not_enough: 'Tolik toho ve skladu nemáš.',
  max_count: 'Tohle už máš postavené.',
  no_object: 'Tahle budova neexistuje.',
  queue_full: 'Výroba je plná – počkej nebo vyber hotové.',
  no_inputs: 'Chybí suroviny.',
  no_feed: 'Nemáš krmivo – vyrob ho v Krmivárně.',
  nothing: 'Teď tu není co dělat.',
  no_home: 'Nejdřív postav pro zvíře ohradu.',
  pen_full: 'Ohrada je plná.',
  fixed: 'Statek stojí pevně uprostřed farmy.',
  no_machine: 'Na tohle potřebuješ stroj z obchodu.',
  max_orchards: 'Víc sadů odemkneš na vyšší úrovni.',
  max_fields: 'Další velké pole odemkneš na vyšší úrovni.',
  bad_size: 'Velké pole může mít 3×3 až 6×6 políček.',
  owned: 'Tenhle stroj už máš.',
  machine_busy: 'Stroj právě pracuje na jiném poli.',
  claimed: 'Dnešní odměnu už máš. Přijď zítra!',
  statek_low: 'Nejdřív vylepši Statek.',
  garage_full: 'Ve stodole není místo – vylepši ji, nebo nějaký stroj prodej.',
  no_garage: 'Stroje potřebuješ někam zaparkovat – postav Stodolu (Stavět).',
  max_level: 'Budova už má nejvyšší úroveň.',
  stall_qty: 'Tolik už stánek nemá nebo nechce.',
  helper_level: 'Pomocníka si najmeš od úrovně 3.',
  no_helper: 'Pomocník teď nepracuje – najmi ho ve Statku.',
  land_owned: 'Tenhle pozemek už je tvůj.',
  land_far: 'Nejdřív kup sousední pozemek.',
  wrong_machine: 'Na tuhle plodinu potřebuješ jiný stroj.',
  not_empty_tree: 'V sadu už strom roste.',
  no_order: 'Tahle zakázka teď není.',
  missing: 'Na zakázku ti ještě něco chybí.',
};

// ---------- akce ----------
// Aplikuje akci na farmu (mění objekt). Vrací { ok, error?, gained? }.
export function applyAction(farm, a, now) {
  normalize(farm);
  if (farm.helper) runHelper(farm, now);
  if (!a || typeof a.type !== 'string') return fail('bad_action');
  switch (a.type) {
    case 'plant': {
      const p = findPlot(farm, a.x, a.y);
      if (!p) return fail('no_plot');
      if (p.crop) return fail('not_empty');
      const c = getCrop(a.crop);
      if (!c) return fail('bad_action');
      if (farm.level < c.level) return fail('locked');
      if (farm.coins < c.cost) return fail('no_coins');
      farm.coins -= c.cost;
      p.crop = c.id;
      p.planted = now;
      return { ok: true };
    }
    case 'harvest': {
      const p = findPlot(farm, a.x, a.y);
      if (!p || !p.crop) return fail('no_plot');
      if (plotState(p, now).state !== 'ready') return fail('not_ready');
      const c = CROPS[p.crop];
      if (siloFree(farm) < c.yield) return fail('silo_full');
      const qty = harvestPlot(farm, p);
      const levelUp = addXp(farm, c.xp);
      return { ok: true, bonus: qty > c.yield, gained: { items: [{ item: c.id, qty }], xp: c.xp, levelUp } };
    }
    case 'sowAll': {
      if (!hasMachine(farm, 'tractor')) return fail('no_machine');
      const c = getCrop(a.crop);
      if (!c) return fail('bad_action');
      if (farm.level < c.level) return fail('locked');
      const empty = farm.plots.filter(p => !p.crop);
      if (!empty.length) return fail('nothing');
      let n = 0;
      for (const p of empty) {
        if (farm.coins < c.cost) break;
        farm.coins -= c.cost;
        p.crop = c.id; p.planted = now; n++;
      }
      if (!n) return fail('no_coins');
      return { ok: true, count: n };
    }
    case 'harvestAll': {
      if (!hasMachine(farm, 'combine')) return fail('no_machine');
      const ready = farm.plots.filter(p => plotState(p, now).state === 'ready');
      if (!ready.length) return fail('not_ready');
      const items = []; let xp = 0, n = 0;
      for (const p of ready) {
        const c = CROPS[p.crop];
        if (siloFree(farm) < c.yield) break;
        addItem(farm, c.id, c.yield);
        items.push({ item: c.id, qty: c.yield });
        xp += c.xp; n++;
        p.crop = null; p.planted = 0;
      }
      if (!n) return fail('silo_full');
      const levelUp = addXp(farm, xp);
      return { ok: true, count: n, partial: n < ready.length, gained: { items: mergeItems(items), xp, levelUp } };
    }
    case 'buyPlot': {
      if (!fits(farm, a.x, a.y, 1, 1)) return fail(isInt(a.x) && isInt(a.y) && landOwned(farm, a.x, a.y) ? 'occupied' : 'out_of_farm');
      if (farm.plots.length >= maxPlots(farm.level)) return fail('max_plots');
      const price = plotPrice(farm);
      if (farm.coins < price) return fail('no_coins');
      farm.coins -= price;
      farm.plots.push({ x: a.x, y: a.y, crop: null, planted: 0 });
      return { ok: true };
    }
    case 'sell': {
      const it = getItem(a.item);
      if (!it || !isInt(a.qty) || a.qty <= 0) return fail('bad_action');
      if (have(farm, it.id) < a.qty) return fail('not_enough');
      takeItem(farm, it.id, a.qty);
      const earned = a.qty * sellPrice(it.id, now);
      farm.coins += earned;
      addStat(farm, 'sold', earned);
      return { ok: true };
    }
    case 'place': {
      const d = getBuilding(a.kind);
      if (!d || d.type === 'main') return fail('bad_action');
      const free = farm.pending.includes(d.id);
      let { w, h } = d;
      if (d.type === 'bigfield') {
        w = a.w; h = a.h;
        if (!isInt(w) || !isInt(h) || w < FIELD_MIN || h < FIELD_MIN || w > FIELD_MAX || h > FIELD_MAX) return fail('bad_size');
      }
      const cost = d.type === 'orchard' ? orchardPrice(farm) : d.type === 'bigfield' ? w * h * FIELD_CELL_PRICE : d.cost;
      if (!free) {
        if (['storage', 'dealer', 'stall'].includes(d.type)) return fail('max_count');
        if (farm.level < d.level) return fail('locked');
        if (d.st > statekLevel(farm)) return fail('statek_low');
        if (d.max && countKind(farm, d.id) >= d.max) return fail('max_count');
        if (d.type === 'orchard' && countKind(farm, 'sad') >= maxOrchards(farm.level)) return fail('max_orchards');
        if (d.type === 'bigfield' && countKind(farm, 'velkepole') >= maxBigFields(farm.level)) return fail('max_fields');
      }
      if (!fits(farm, a.x, a.y, w, h)) return fail('occupied');
      if (!free && farm.coins < cost) return fail('no_coins');
      if (free) farm.pending.splice(farm.pending.indexOf(d.id), 1);
      else farm.coins -= cost;
      const o = { id: farm.nextId++, kind: d.id, x: a.x, y: a.y };
      if (d.type === 'factory') o.queue = [];
      if (d.type === 'pen') o.animals = [];
      if (d.type !== 'deco' && d.type !== 'orchard' && d.type !== 'bigfield') o.lvl = 1;
      if (d.type === 'orchard') { o.tree = null; o.readyAt = 0; o.left = 0; o.dead = false; }
      if (d.type === 'bigfield') { o.w = w; o.h = h; o.crop = null; o.job = null; o.readyAt = 0; o.load = null; o.soil = 'raw'; o.straw = false; }
      farm.objects.push(o);
      const levelUp = addXp(farm, d.xp);
      return { ok: true, id: o.id, gained: { items: [], xp: d.xp, levelUp } };
    }
    case 'move': {
      const o = findObject(farm, a.id);
      if (!o) return fail('no_object');
      const d = BUILDINGS[o.kind];
      if (d.type === 'main') return fail('fixed');
      const sz = objSize(o);
      if (!fits(farm, a.x, a.y, sz.w, sz.h, o.id)) return fail('occupied');
      o.x = a.x; o.y = a.y;
      return { ok: true };
    }
    case 'produce': {
      const o = findObject(farm, a.id);
      if (!o || BUILDINGS[o.kind].type !== 'factory') return fail('no_object');
      const r = getRecipe(a.recipe);
      if (!r || r.building !== o.kind) return fail('bad_action');
      if (farm.level < r.level) return fail('locked');
      if (o.queue.length >= queueSize(o)) return fail('queue_full');
      if (!hasInputs(farm, r)) return fail('no_inputs');
      for (const [id, n] of Object.entries(r.in)) takeItem(farm, id, n);
      const last = o.queue.length ? o.queue[o.queue.length - 1].end : 0;
      const d = Math.round(r.time * 1000 * speedMult(o));
      o.queue.push({ r: r.id, end: Math.max(now, last) + d, d });
      return { ok: true };
    }
    case 'collect': {
      const o = findObject(farm, a.id);
      if (!o) return fail('no_object');
      const d = BUILDINGS[o.kind];
      const items = [];
      let xp = 0, full = false, anyReady = false;
      if (d.type === 'factory') {
        while (o.queue.length && o.queue[0].end <= now) {
          anyReady = true;
          if (siloFree(farm) < 1) { full = true; break; }
          const q = o.queue.shift();
          addItem(farm, q.r, 1);
          items.push({ item: q.r, qty: 1 });
          xp += RECIPES[q.r].xp;
        }
      } else if (d.type === 'pen') {
        const an = ANIMALS[d.animal];
        for (const x of o.animals) {
          if (animalState(x, an, now).state !== 'ready') continue;
          anyReady = true;
          if (siloFree(farm) < 1) { full = true; break; }
          x.fed = 0;
          addItem(farm, an.product, 1);
          items.push({ item: an.product, qty: 1 });
          xp += an.xp;
        }
      } else return fail('bad_action');
      if (!items.length) return fail(full ? 'silo_full' : anyReady ? 'silo_full' : 'not_ready');
      const levelUp = addXp(farm, xp);
      return { ok: true, gained: { items: mergeItems(items), xp, levelUp }, partial: full };
    }
    case 'feed': {
      const o = findObject(farm, a.id);
      if (!o || BUILDINGS[o.kind].type !== 'pen') return fail('no_object');
      const an = ANIMALS[BUILDINGS[o.kind].animal];
      const hungry = o.animals.filter(x => !x.fed);
      if (!hungry.length) return fail('nothing');
      let fed = 0;
      for (const x of hungry) {
        if (have(farm, an.feed) < 1) break;
        takeItem(farm, an.feed, 1);
        x.fed = now;
        x.dur = Math.round(an.time * 1000 * speedMult(o));
        fed++;
      }
      if (!fed) return fail('no_feed');
      return { ok: true, fed };
    }
    case 'buyAnimal': {
      const an = own(ANIMALS, a.animal);
      if (!an) return fail('bad_action');
      if (farm.level < an.level) return fail('locked');
      const home = farm.objects.find(o => o.kind === an.home && o.animals.length < penMax(o));
      if (!home) return fail(countKind(farm, an.home) ? 'pen_full' : 'no_home');
      if (farm.coins < an.cost) return fail('no_coins');
      farm.coins -= an.cost;
      home.animals.push({ fed: 0 });
      return { ok: true, id: home.id };
    }
    case 'upgradeSilo': {
      const price = siloUpgradePrice(farm);
      if (farm.coins < price) return fail('no_coins');
      farm.coins -= price;
      farm.siloCap += SILO_STEP;
      return { ok: true };
    }
    case 'plantTree': {
      const o = findObject(farm, a.id);
      if (!o || BUILDINGS[o.kind].type !== 'orchard') return fail('no_object');
      if (o.tree) return fail('not_empty_tree');
      const t = own(TREES, a.tree);
      if (!t) return fail('bad_action');
      if (farm.level < t.level) return fail('locked');
      if (farm.coins < t.cost) return fail('no_coins');
      farm.coins -= t.cost;
      o.tree = t.id; o.left = t.harvests; o.dead = false; o.readyAt = now + t.first * 1000;
      return { ok: true };
    }
    case 'harvestTree': {
      const o = findObject(farm, a.id);
      if (!o || BUILDINGS[o.kind].type !== 'orchard') return fail('no_object');
      if (treeState(o, now).state !== 'ready') return fail('not_ready');
      const t = TREES[o.tree];
      if (siloFree(farm) < t.yield) return fail('silo_full');
      addItem(farm, t.fruit, t.yield);
      const levelUp = addXp(farm, t.xp);
      o.left--;
      if (o.left > 0) o.readyAt = now + t.regrow * 1000; else o.dead = true;
      return { ok: true, gained: { items: [{ item: t.fruit, qty: t.yield }], xp: t.xp, levelUp }, dead: o.dead };
    }
    case 'clearTree': {
      const o = findObject(farm, a.id);
      if (!o || BUILDINGS[o.kind].type !== 'orchard' || !o.tree) return fail('no_object');
      if (!o.dead) return fail('not_ready');
      o.tree = null; o.dead = false; o.readyAt = 0; o.left = 0;
      return { ok: true };
    }
    case 'buyMachine': {
      const m = own(MACHINES, a.model);
      if (!m) return fail('bad_action');
      if (farm.level < m.level) return fail('locked');
      if (farm.machines.some(x => x.model === m.id)) return fail('owned');
      if (isVehicle(m.id) && vehicleCount(farm) >= garageSlots(farm)) return fail(countKind(farm, 'stodola') ? 'garage_full' : 'no_garage');
      const price = machinePrice(farm, m.id);
      if (farm.coins < price) return fail('no_coins');
      farm.coins -= price;
      const id = farm.nextId++;
      farm.machines.push({ id, model: m.id });
      const levelUp = addXp(farm, 5);
      return { ok: true, id, gained: { items: [], xp: 5, levelUp } };
    }
    case 'fieldSow': {
      const o = findObject(farm, a.id);
      if (!o || BUILDINGS[o.kind].type !== 'bigfield') return fail('no_object');
      if (fieldState(o, now).state !== 'empty') return fail('not_empty');
      const c = getCrop(a.crop);
      if (!c) return fail('bad_action');
      if (farm.level < c.level) return fail('locked');
      const m = findMachine(farm, a.machine);
      if (!m || MACHINES[m.model].type !== 'tractor') return fail('no_machine');
      if (machineJob(farm, m.id, now)) return fail('machine_busy');
      const cells = o.w * o.h;
      if (farm.coins < c.cost * cells) return fail('no_coins');
      farm.coins -= c.cost * cells;
      const sec = Math.ceil(jobSeconds(cells, m.model) / (hasTool(farm, 'seeder') ? 2 : 1));
      o.mult = o.soil === 'plowed' ? 1.5 : 1;
      o.soil = 'sown'; o.straw = false;
      o.crop = c.id;
      o.job = { type: 'sow', m: m.id, start: now, end: now + sec * 1000 };
      o.readyAt = o.job.end + c.time * 1000;
      o.load = null;
      addStat(farm, 'jobs', 1);
      return { ok: true };
    }
    case 'fieldHarvest': {
      const o = findObject(farm, a.id);
      if (!o || BUILDINGS[o.kind].type !== 'bigfield') return fail('no_object');
      if (fieldState(o, now).state !== 'ready') return fail('not_ready');
      const m = findMachine(farm, a.machine);
      if (!m) return fail('no_machine');
      if (MACHINES[m.model].type !== CROPS[o.crop].harvester) return fail('wrong_machine');
      if (machineJob(farm, m.id, now)) return fail('machine_busy');
      o.job = { type: 'harvest', m: m.id, start: now, end: now + jobSeconds(o.w * o.h, m.model) * 1000 };
      o.load = { item: o.crop, qty: fieldYield(o), xp: CROPS[o.crop].xp * o.w * o.h };
      o.straw = CROPS[o.crop].harvester === 'combine';
      o.crop = null; o.readyAt = 0; o.soil = 'stubble';
      addStat(farm, 'jobs', 1);
      return { ok: true };
    }
    case 'fieldPlow':
    case 'fieldBale': {
      const o = findObject(farm, a.id);
      if (!o || BUILDINGS[o.kind].type !== 'bigfield') return fail('no_object');
      const st = fieldState(o, now);
      if (st.state !== 'empty') return fail('not_empty');
      const plow = a.type === 'fieldPlow';
      if (!hasTool(farm, plow ? 'plow' : 'baler')) return fail('no_machine');
      if (plow && o.soil === 'plowed') return fail('nothing');
      if (!plow && !o.straw) return fail('nothing');
      const m = findMachine(farm, a.machine);
      if (!m || MACHINES[m.model].type !== 'tractor') return fail('no_machine');
      if (machineJob(farm, m.id, now)) return fail('machine_busy');
      o.job = { type: plow ? 'plow' : 'bale', m: m.id, start: now, end: now + jobSeconds(o.w * o.h, m.model) * 1000 };
      if (plow) { o.soil = 'plowed'; o.straw = false; }
      else { o.straw = false; o.load = { item: 'slama', qty: Math.floor(o.w * o.h / 2), xp: 0 }; }
      addStat(farm, 'jobs', 1);
      return { ok: true };
    }
    case 'fieldUnload': {
      const o = findObject(farm, a.id);
      if (!o || BUILDINGS[o.kind].type !== 'bigfield') return fail('no_object');
      const st = fieldState(o, now);
      if (st.state !== 'unload') return fail('not_ready');
      const n = Math.min(st.stock, siloFree(farm));
      if (n <= 0) return fail('silo_full');
      addItem(farm, o.load.item, n);
      const xp = o.load.xp || 0;
      o.load.xp = 0;
      o.load.qty -= n;
      const levelUp = xp ? addXp(farm, xp) : 0;
      const rest = o.load.qty;
      const item = o.load.item;
      if (!rest) o.load = null;
      return { ok: true, rest, gained: { items: [{ item, qty: n }], xp, levelUp } };
    }
    case 'upgrade': {
      const o = findObject(farm, a.id);
      if (!o) return fail('no_object');
      const c = upgradeCost(o);
      if (!c) return fail(UP_BASE[BUILDINGS[o.kind].type] ? 'max_level' : 'bad_action');
      if (c.player && farm.level < c.player) return fail('locked');
      if (!c.player && c.level > statekLevel(farm)) return fail('statek_low');
      if (c.items.some(x => have(farm, x.item) < x.qty)) return fail('no_inputs');
      if (farm.coins < c.coins) return fail('no_coins');
      for (const x of c.items) takeItem(farm, x.item, x.qty);
      farm.coins -= c.coins;
      o.lvl = c.level;
      if (BUILDINGS[o.kind].type === 'storage') farm.siloCap += 40;
      const levelUp = addXp(farm, 5 * c.level);
      return { ok: true, level: c.level, gained: { items: [], xp: 5 * c.level, levelUp } };
    }
    case 'sellMachine': {
      const m = findMachine(farm, a.id);
      if (!m) return fail('no_machine');
      if (machineJob(farm, m.id, now)) return fail('machine_busy');
      const refund = Math.round(MACHINES[m.model].cost * 0.5);
      farm.machines = farm.machines.filter(x => x.id !== m.id);
      farm.coins += refund;
      return { ok: true, refund };
    }
    case 'stallBuy':
    case 'stallSell': {
      const offers = stallOffers(farm, now);
      const buy = a.type === 'stallBuy';
      const list = buy ? offers.buy : offers.sell;
      const off = isInt(a.i) ? list[a.i] : null;
      if (!off || !isInt(a.qty) || a.qty <= 0) return fail('bad_action');
      const st = stallState(farm, now);
      const key = buy ? 'b' : 's';
      if ((st[key][a.i] || 0) + a.qty > off.qty) return fail('stall_qty');
      const total = off.price * a.qty;
      if (buy) {
        if (farm.coins < total) return fail('no_coins');
        if (siloFree(farm) < a.qty) return fail('silo_full');
        farm.coins -= total;
        farm.silo[off.item] = (farm.silo[off.item] || 0) + a.qty;
      } else {
        if (have(farm, off.item) < a.qty) return fail('not_enough');
        takeItem(farm, off.item, a.qty);
        farm.coins += total;
        addStat(farm, 'sold', total);
      }
      st[key][a.i] = (st[key][a.i] || 0) + a.qty;
      return { ok: true, total };
    }
    case 'hire': {
      const plan = isInt(a.plan) ? HELPER_PLANS[a.plan] : null;
      if (!plan) return fail('bad_action');
      if (farm.level < HELPER_LEVEL) return fail('helper_level');
      if (a.crop !== null && a.crop !== undefined && !getCrop(a.crop)) return fail('bad_action');
      if (farm.coins < plan.cost) return fail('no_coins');
      farm.coins -= plan.cost;
      if (helperActive(farm, now)) farm.helper.until += plan.h * 3600000;
      else farm.helper = { until: now + plan.h * 3600000, last: now, crop: a.crop || null, tractor: !!(farm.helper && farm.helper.tractor), n: 0 };
      if (a.crop) farm.helper.crop = a.crop;
      return { ok: true };
    }
    case 'helperSet': {
      if (!farm.helper) return fail('no_helper');
      if (a.crop !== undefined) {
        if (a.crop !== null && !getCrop(a.crop)) return fail('bad_action');
        farm.helper.crop = a.crop;
      }
      if (a.tractor !== undefined) farm.helper.tractor = !!a.tractor;
      return { ok: true };
    }
    case 'buyLand': {
      const p = getParcel(a.id);
      if (!p) return fail('bad_action');
      if (farm.land.includes(p.id)) return fail('land_owned');
      if (!landReachable(farm, p)) return fail('land_far');
      if (farm.level < landLevel(farm)) return fail('locked');
      const price = landPrice(farm);
      if (farm.coins < price) return fail('no_coins');
      farm.coins -= price;
      farm.land.push(p.id);
      const levelUp = addXp(farm, 20);
      return { ok: true, price, gained: { items: [], xp: 20, levelUp } };
    }
    case 'claimDaily': {
      const today = dayKey(now);
      if (farm.daily.day === today) return fail('claimed');
      const yesterday = dayKey(now - 86400000);
      const streak = farm.daily.day === yesterday ? farm.daily.streak % 7 + 1 : 1;
      const r = DAILY[streak - 1];
      farm.daily = { day: today, streak };
      farm.coins += r.coins;
      const levelUp = r.xp ? addXp(farm, r.xp) : 0;
      return { ok: true, streak, coins: r.coins, gained: { items: [], xp: r.xp || 0, levelUp } };
    }
    case 'claimAch': {
      const ach = ACHIEVEMENTS.find(x => x.id === a.id);
      if (!ach) return fail('bad_action');
      const tier = farm.ach[ach.id] || 0;
      if (tier >= ach.tiers.length) return fail('nothing');
      if ((farm.stats[ach.stat] || 0) < ach.tiers[tier]) return fail('not_ready');
      farm.ach[ach.id] = tier + 1;
      farm.coins += ach.coins[tier];
      return { ok: true, coins: ach.coins[tier], tier: tier + 1 };
    }
    case 'deliver': {
      const o = isInt(a.slot) ? farm.orders[a.slot] : null;
      if (!o || !orderReady(o, now)) return fail('no_order');
      if (!canDeliver(farm, o)) return fail('missing');
      for (const x of o.items) takeItem(farm, x.item, x.qty);
      farm.coins += o.coins;
      addStat(farm, 'orders', 1);
      const levelUp = addXp(farm, o.xp);
      const coins = o.coins, xp = o.xp;
      farm.orders[a.slot] = genOrder(farm, now);
      return { ok: true, coins, gained: { items: [], xp, levelUp } };
    }
    case 'discard': {
      const o = isInt(a.slot) ? farm.orders[a.slot] : null;
      if (!o || !orderReady(o, now)) return fail('no_order');
      farm.orders[a.slot] = genOrder(farm, now + ORDER_WAIT * 1000);
      return { ok: true };
    }
    default:
      return fail('bad_action');
  }
}

function mergeItems(list) {
  const m = {};
  for (const { item, qty } of list) m[item] = (m[item] || 0) + qty;
  return Object.entries(m).map(([item, qty]) => ({ item, qty }));
}
